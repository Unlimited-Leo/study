#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <wait.h>
#include <sys/msg.h>

#define BUFF 1024

struct shbuf
{
    long msg_type;
    char msg_t[BUFF];
};

int main()
{
    int qid;
    key_t key;
    struct shbuf sh_buf;

    if((key = ftok(".",'d'))==-1)
    {
        perror("fotk error\n");
        exit(1);
    }
    if((qid = msgget(key,IPC_CREAT|0666))==-1)
    {
        perror("pid error\n");
        exit(1);
    }
    printf("open pid %d\n",qid);

    do
    {
        memset(sh_buf.msg_t,0,BUFF);

        if(msgrcv(qid,(void *)&sh_buf,BUFF,0,0)<0)
        {
            perror("msgrcv error\n");
            exit(1);
        }
        printf("the message process %ld : %s",sh_buf.msg_type,sh_buf.msg_t);

    }
    while(strncmp(sh_buf.msg_t,"quit",4));

    if((msgctl(qid,IPC_RMID,NULL))<0)
    {
        perror("msgctl\n");
        exit(1);
    }




    exit(0);

}