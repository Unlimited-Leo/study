#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <wait.h>
#include <sys/msg.h>

#define BUFF 1024

struct shbuf
{
    long msg_type;
    char msg_t[BUFF];
};

int main()
{
    int qid;
    key_t key;
    struct shbuf sh_buf;

    if((key = ftok(".",'d'))==-1)
    {
        perror("fotk error\n");
        exit(1);
    }
    if((qid = msgget(key,IPC_CREAT|0666))==-1)
    {
        perror("pid error\n");
        exit(1);
    }
    printf("open pid %d\n",qid);
    printf("my pid %d\n",getpid());

    while(1)
    {
        printf("Enter some message to the queue(enter 'quit' to exit):");
        if((fgets(sh_buf.msg_t,BUFF,stdin)) == NULL)
        {
            perror("on message\n");
            exit(1);
        }
        sh_buf.msg_type = getpid();

        if((msgsnd(qid,&sh_buf,strlen(sh_buf.msg_t),0))< 0)
        {
            perror("message posted\n");
            exit(1);
        }
        if(strncmp(sh_buf.msg_t,"quit",4) == 0)
        {
            break;
        }

    }
    exit(0);

}