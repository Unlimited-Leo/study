#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <wait.h>
#include <sys/sem.h>

union semun
{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
};

int init_sem(int, int);
int del_sem(int);
int sem_p(int);
int sem_v(int);


#define BUFF 1024

struct sh_buf
{
    char buf[BUFF];
}*sh_pbuf;

int main(void)
{
    int shm_id,sem_id;
    key_t key,semkey;
    pid_t pid;
   // sh_buf *sh_pbuf;


     key = ftok("./tmp.txt",0);
    shm_id = shmget(key,sizeof(struct sh_buf),0666|IPC_CREAT);
    if(shm_id==-1)
    {
        printf("shmget error\n");
        exit(1);
    }

    sh_pbuf=shmat(shm_id,NULL,0);
    if(sh_pbuf == (void *)-1)
    {
            printf("shmat error\n");
            exit(1);
    }

    semkey = ftok(".",'b');
    sem_id = semget(semkey,1,IPC_CREAT|0666);

    if(sem_id == -1)
    {
        printf("semget error\n");
        exit(1);
    }

    do
    {
        printf("write message:\n");
        gets(sh_pbuf->buf);
        sem_v(sem_id);


    }
    while(strncmp(sh_pbuf->buf,"quit",4));

    printf("write over\n");

        if((shmdt(sh_pbuf))<0) //撤销地址映射
        {
            printf("shmdt error\n");
            exit(1);
        }
        if((shmctl(shm_id,IPC_RMID,NULL))<0)
        {
            printf("shmctl error\n");
            exit(1);

        }


        exit(0);

    return 0;

}

int init_sem(int sem_id, int init_value)
{
	union semun sem_union;
	sem_union.val = init_value;
	if (semctl(sem_id, 0, SETVAL, sem_union) == -1)
	{
		perror("Initialize semaphore");
		return -1;
	}
	return 0;
}

int del_sem(int sem_id)
{
	union semun sem_union;
	if (semctl(sem_id, 0, IPC_RMID, sem_union) == -1)
	{
		perror("Delete semaphore");
		return -1;
	}
}

int sem_p(int sem_id)
{
	struct sembuf sem_b;
	sem_b.sem_num = 0; /*id*/
	sem_b.sem_op = -1; /* P operation*/
	sem_b.sem_flg = SEM_UNDO;

	if (semop(sem_id, &sem_b, 1) == -1)
	{
		perror("P operation");
		return -1;
	}
	return 0;
}

int sem_v(int sem_id)
{
	struct sembuf sem_b;

	sem_b.sem_num = 0; /* id */
	sem_b.sem_op = 1; /* V operation */
	sem_b.sem_flg = SEM_UNDO;

	if (semop(sem_id, &sem_b, 1) == -1)
	{
		perror("V operation");
		return -1;
	}
	return 0;
}