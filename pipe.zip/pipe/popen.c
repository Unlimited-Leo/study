#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUFFER_SIZE 256

int main(void)
{
	FILE *fp;
	char buf[BUFFER_SIZE];
	memset((void *)buf,0,sizeof(buf));
	//char cmd[]="./hello"
	
	//创建标准流管道（1.创建管道 2.创建子进程  3.关闭父子进程中不需要的描述符）
	//  (4.在子进程中调用exec函数 5.把子进程替换成“./hello”)
	
	//父进程main跟被替换成hello的子进程之间，进行通信
	//"r"----表示当前的main进程读管道，hello进程写管道
	
	fp=popen("./hello","r");//creat pipe link to hello 
	
	if(fp==NULL)
	{
		printf("popen error!\n");
		exit(0);
	}
	if( (fread(buf,1,BUFFER_SIZE,fp)) >0)//read data form pipe "fd"
	{
		printf("From pipe read is: %s\n",buf);
	}
	pclose(fp);
	return 0;
}
