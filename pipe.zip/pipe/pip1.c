#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

#include<string.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 322

int main(void)
{
    char str[] ="hello world!\n";
    char buf[BUFFER_SIZE];
    pid_t pid;
    int fd[2],real_read,real_write;
    memset((void*)buf,0,sizeof(buf));


	if( pipe(fd)  ==  -1)
	{
		printf("pipe error!\n");
		return -1;
	}

    pid = fork();
	if(-1==pid)
	{
		printf("fork error!\n");
		return -1;
	}
    else if(pid == 0)
    {

        close(fd[1]);
         sleep(2);
    printf("child,read\n");

        if((real_read = read(fd[0],buf,BUFFER_SIZE))>0)
        {
            printf("child:%d\n read:%s\n",real_read,buf);

        }
        close(fd[0]);//不再读了，也关闭读端描述符
		exit(0);
      }

     close(fd[0]);
     sleep(1);
        printf("parent,read\n");
       if((real_write = write(fd[1],str,strlen(str))) != -1)
       {
           printf("parent:%d\n write:%s\n",real_write,str);
       }

        close(fd[1]);
        //sleep(1);
        wait(NULL);
        exit(0);
        return 0;


}