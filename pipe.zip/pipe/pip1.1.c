#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 322

int main(void)
{
    FILE * fp;
    char buf[BUFFER_SIZE];
    memset((void*)buf,0,sizeof(buf));
    fp = popen("./hello","r");
    //创建标准流管道
    //创建管道，创建子进程，关闭父子进程中不需要的描述符
    //在子进程中调用exec函数，把子进程自己替换成'./hello'
    //父进程main
    if(fp == NULL)
    {
      perror("fail to popen\n");
      exit(0);
     }

    if((fread(buf,1,BUFFER_SIZE,fp))>0)
    {
        printf("over read file:%s\n",buf);

    }

    pclose(fp);
    return 0;
}