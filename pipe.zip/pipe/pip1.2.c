#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<string.h>
#include<errno.h>
#include<fcntl.h>
#include<limits.h>

#define MYFIFO "./myfifo"

#define BUFFER_SIZE PIPE_BUF
int main(int argc,char *argv[])
{
    int fp_myfifo;
    char buf[BUFFER_SIZE];
    memset((void*)buf,0,sizeof(buf));

    if(access(MYFIFO,F_OK)==-1)
    {
      printf("Please create fifo in read process!\n");
		return -1;
     }


    if((fp_myfifo = open(MYFIFO,O_WRONLY)) == -1)
    {
        printf("write open myfifo error\n");
		return -1;
    }

    if(argc <= 1)
    {
        printf("usage: ./write transfer_words\n");
        return -1;
    }
    strcpy(buf,argv[1]);

    if(write(fp_myfifo,buf,strlen(buf))>0)
    {
        printf("In write process,transfered: %s\n",buf);
    }

    close(fp_myfifo);
    return -1;
}