#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

#include<string.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 256

int main(void)
{
	int pipe_fd[2],real_read,real_write;
	pid_t pid;
	char buf[BUFFER_SIZE];
	char test_data[]="Hello,this pipe test!\n";
	
	memset((void*)buf,0,sizeof(buf));
	
	//创建匿名管道
	if( pipe(pipe_fd)  ==  -1)
	{
		printf("pipe error!\n");
		return -1;
	}
	
	//创建子进程
	pid=fork();
	
	if(-1==pid)
	{
		printf("fork error!\n");
		return -1;
	}
	else if(0==pid)//In child process
	{
		close(pipe_fd[1]);//子进程关闭写端描述符（子进程只读不写）
		sleep(3);//wait parent write
		
		if((real_read = read(pipe_fd[0],buf,BUFFER_SIZE)) > 0)
		{
			printf("In child process:\n%d bytes child read from pipe is %s\n",real_read,buf);
		}
		
		close(pipe_fd[0]);//不再读了，也关闭读端描述符
		exit(0);
	}
	
	
	//以下是父进程执行的代码
	close(pipe_fd[0]);//父进程关闭读端描述符（只写不读）
	
	sleep(1);//wait child close pipe write fd
	
	if((real_write = write(pipe_fd[1],test_data,strlen(test_data))) != -1)
	{
		printf("In parent process:\n%d bytes parent write to pipe is %s\n",real_write,test_data);
	}	
	close(pipe_fd[1]);//父进程写完，不再写了，也关闭了写端描述符
	wait(NULL);//等子进程退出
	exit(0);
	return 0;
}
