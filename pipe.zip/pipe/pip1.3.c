#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<string.h>
#include<errno.h>
#include<fcntl.h>
#include<limits.h>

#define MYFIFO "./myfifo"

#define BUFFER_SIZE PIPE_BUF

int main(void)
{
    int  fp_myfifo;
    char buf[BUFFER_SIZE];
   // memset((void*)buf,0,sizeof(buf));
    //fp = popen("./hello","r");
    //创建标准流管道
    //创建管道，创建子进程，关闭父子进程中不需要的描述符
    //在子进程中调用exec函数，把子进程自己替换成'./hello'
    //父进程main
    if(access(MYFIFO,F_OK)==-1)
    {
      if((mkfifo(MYFIFO,066)<0)&&(errno != EEXIST))
      {
          printf("mkfifo error!\n");
          return -1;
      }

     }

    fp_myfifo = open("./myfifo",O_RDONLY);

    if(fp_myfifo == -1)
    {
        printf("open myfifo error\n");
		return -1;
    }

    printf("exit\n");
    do
    {
        memset((void*)buf,0,sizeof(buf));
        if((read(fp_myfifo,buf,BUFFER_SIZE))>0)
        {
            printf("over:%s\n",buf);
        }
    }while(strncmp(buf,"exit",4));
    printf("\n");

    close(fp_myfifo);
    return -1;
}