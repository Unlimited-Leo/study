print("hello,word")

#from cs50 import get_string

#answer = get_string("what's your name?\n")
answer = input("what's your name?\n")
#print("hello,"+answer)
print(f"hello,{answer}")