import csv
from cs50 import get_string

name = get_string("Name: ")
number = get_string("Number: ")

with open("phonebook.csv","a")as file:
#file = open("phonebook.csv","a")
    writer = csv.writer(file)
    writer.writerow([name,number])

#file.close()


'''
上一段内容
from cs50 import get_string

people = {
    "Carter":"+1-617-495-1000",
    "Leo":"+1-123-456-7890",
    "David":"+1-949-468-2750"
}
name = get_string("Name: ")
if name in people:
    number = people[name]
    print(f"Number:{number}")
'''