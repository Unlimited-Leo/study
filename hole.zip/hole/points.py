from cs50 import get_int

n = get_int("n: ")

if n % 2 == 0:
    print("even")
else:
    print("odd")


'''
points = get_int("How many points did you lose?  ")

if points < 2 :
    print("You lost fewer points than me. ")
elif points > 2:
   print("You lost more points than me.")
else :
    print("You the same number of points as me.")
'''