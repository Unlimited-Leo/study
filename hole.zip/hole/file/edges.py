from PIL import Image , ImageFilter

before = Image.open("END.png")
after = before.filter(ImageFilter.FIND_EDGES)
after.save("out1.png")