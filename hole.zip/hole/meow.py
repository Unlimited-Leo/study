def main():
    #for i in range(3):
         meow(3)

def meow(n):
    for i in range(n):
         print("meow")

#main()

if __name__ == '__main__':
    main()