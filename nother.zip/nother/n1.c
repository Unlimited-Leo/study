#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>

#define BUFF 1024

typedef struct shbuf //共享内存结构体
{
    int flag_w;
    char buf[BUFF];
}sh_buf;


int main(void)
{
    int shm_id;
    pid_t pid;
    sh_buf * sh_pbuf;


    shm_id = shmget(IPC_PRIVATE,sizeof(sh_buf),0666);
    if(shm_id == -1)
    {
        perror("shm_id error\n");
        return -1;
    }
    else
    {
        printf("shm_id is %d\n",shm_id);
        system("ipcs -m");
    }

    pid = fork();
    if(pid == -1)
    {
        perror("fork error\n");
         exit(1);
    }
    else if(pid == 0)
    {
        sh_pbuf = shmat(shm_id,NULL,0);//映射，并获得映射地址
        if(sh_pbuf == (void *)-1)
        {
            perror("shmat error\n");
            exit(1);
        }
        else
        {
            printf("child attach shm is %p\n",sh_pbuf);
            system("ipcs -m");
        }

        do
        {
            if(sh_pbuf->flag_w!=1)
            {
                printf("wait father write message!!\n");
                while(sh_pbuf->flag_w!=1);
                printf("from father message:%s\n",sh_pbuf->buf);
                sh_pbuf->flag_w=0;//标记数据已读走
            }
        }
        while(strncmp(sh_pbuf->buf,"quit",4));
        printf("father bye\n");
        if((shmdt(sh_pbuf))<0)//撤销地址映射
        {
            printf("shmdt error\n");
            exit(1);
        }
        exit(0);

    }
    else
    {
        sh_pbuf=shmat(shm_id,NULL,0);
        if(sh_pbuf == (void *)-1)
        {
             printf("shmat error\n");
            exit(1);
        }
        else
        {
            printf("father attach shm_id is %p\n",sh_pbuf);
            system("ipcs -m");
        }
        sh_pbuf->flag_w=0;
        do
        {
            if(sh_pbuf->flag_w == 0)
            {
                memset((void *)sh_pbuf->buf,0,BUFF);
                printf("in father process:\nplease write message\n");
                gets(sh_pbuf->buf);
                sh_pbuf->flag_w=1;//标记已写数据
            }
        }
        while(strncmp(sh_pbuf->buf,"quit",4));
        waitpid(pid,NULL,0);
        printf("child bye\n");
        if((shmdt(sh_pbuf))<0) //撤销地址映射
        {
            printf("shmdt error\n");
            exit(1);
        }
        if((shmctl(shm_id,IPC_RMID,NULL))<0)
        {
            printf("shmctl error\n");
            exit(1);

        }
        exit(0);
    }
    return 0;
}